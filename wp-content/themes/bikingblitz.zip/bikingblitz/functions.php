<?php
function bikingblitz_styles() {

    wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/assets/css/bootstrap.min.css', array(), '1.0.0', 'all');

    wp_enqueue_style( 'helper', get_template_directory_uri().'/assets/font_icon/css/helper.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'pe-icon-7-stroke', get_template_directory_uri().'/assets/font_icon/css/pe-icon-7-stroke.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'owl.carousel', get_template_directory_uri().'/assets/css/owl.carousel.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'owl.theme', get_template_directory_uri().'/assets/css/owl.theme.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'animate', get_template_directory_uri().'/assets/css/animate.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'style', get_template_directory_uri().'/assets/css/style.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'font-awesome', get_template_directory_uri().'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '1.0.0', 'all');

    wp_enqueue_style( 'http://fonts.googleapis.com/css?family=Dosis:200,300,400,500|Lato:300,400,700,900,300italic,400italic,700italic,900italic|Raleway:400,200,300,500,100|Titillium+Web:400,200,300italic,300,200italic', array(), '1.0.0', 'all');

    wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/assets/js/modernizr.js' );
    wp_enqueue_script( 'jquery-2', get_template_directory_uri() . '/assets/js/jquery-2.1.3.min.js' );
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js' );
    wp_enqueue_script( 'jquery-actual', get_template_directory_uri() . '/assets/js/jquery.actual.min.js' );
    wp_enqueue_script( 'smooth-scroll', get_template_directory_uri() . '/assets/js/smooth-scroll.js' );
    wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.js' );
    wp_enqueue_script( 'script', get_template_directory_uri() . '/assets/js/script.js' );
    wp_enqueue_script( 'googlemaps', get_template_directory_uri() . 'https://maps.googleapis.com/maps/api/js?key=AIzaSyCgGiKMBjsWPBUDzeeByQ2LKtM73A9WV5w' );

}
add_action( 'wp_enqueue_scripts', 'bikingblitz_styles' );

if ( ! current_user_can( 'manage_options' ) ) {
    show_admin_bar( false );
}

function change_logo_class( $html ) {

    $html = str_replace( 'custom-logo', 'img-responsive center-block', $html );
    $html = str_replace('custom-logo-link', 'navbar-brand', $html );

    return $html;
}

add_action('after_setup_theme', 'mytheme_setup');

add_theme_support( 'custom-logo' );

function mytheme_setup() {
    add_theme_support('custom-logo');
}

add_action('after_setup_theme', 'mytheme_setup');


/*function wpdocs_filter_wp_title( $title, $sep ) {
    global $paged, $page;

    if ( is_feed() )
        return $title;

    // Add the site name.
    $title .= get_bloginfo( 'name' );

    // Add the site description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );
    if ( $site_description && ( is_home() || is_front_page() ) )
        $title = "$title $sep $site_description";

    // Add a page number if necessary.
    if ( $paged >= 2 || $page >= 2 )
        $title = "$title $sep " . sprintf( __( 'Page %s', 'twentytwelve' ), max( $paged, $page ) );

    return $title;
}
add_filter( 'wp_title', 'wpdocs_filter_wp_title', 10, 2 );*/


function bikingblitz_theme_setup(){
    add_theme_support('menus');

    register_nav_menu('Primary', 'Primary');
}
add_action('wp_enqueue_scripts', 'bikingblitz_theme_setup');



add_theme_support( 'post-thumbnails' );

require_once('wp_bootstrap_navwalker.php');


/*function add_last_nav_item($items) {
  return $items .= '<li><a data-toggle="modal" data-target="#login" >LOGIN</a></li>';
}
add_filter('wp_nav_menu_items','add_last_nav_item');*/

if ( function_exists('register_sidebar') ) {
    register_sidebar(array(
        'description' => 'should appear only on the blog page',
        'before_widget' => '<div id="%1$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="blog-category"><p class="lead">',
        'after_title' => '</p></div>',
    ));
}


add_action('pre_get_posts','four_post_per_cat');

function four_post_per_cat( $query ) {
    if ( ! is_admin() && is_main_query() && is_category() ) {
        $query->set('posts_per_page', 1);
    }
}

//add_image_size( 'wordpress-thumbnail', 200, 200, TRUE );


?>
