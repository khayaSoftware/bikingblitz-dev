<?php get_header()?>
<?php
    /*
*/
?>
<?php require_once("events-home.php");?>
<?php // Show the selected frontpage content.
    if ( have_posts() ) :
while ( have_posts() ) : the_post();
if(is_front_page()):

$custom = get_post_custom();

?>



<!-- Portfolio Area -->

<section id="portfolio" class="portfolio-area">
    <div class="container">

        <div class="row port cs-style-3">
            <div class="col-md-4 col-sm-6 col-xs-12 item-space">
                <div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="<?= $custom['iframe-url'][0] ?>" frameborder="0" allowfullscreen="allowfullscreen"></iframe></div>
            </div>
            <div class="col-md-8 col-sm-6 col-xs-12 item-space">
                <blockquote>
                    <p class="lead"><?php the_content(); ?></p>
                </blockquote>
            </div>
        </div>
    </div>
</section><!-- portfolio -->
<?php
endif;
endwhile;

endif; ?>



<?php get_footer(); ?>
