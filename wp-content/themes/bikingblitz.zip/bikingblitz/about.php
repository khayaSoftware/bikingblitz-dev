<?php get_header()?>
<?php
    /* Template Name: About */
?>
<?php // Show the selected frontpage content.
    if ( have_posts() ) :
while ( have_posts() ) : the_post();

$custom = get_post_custom();

?>



<!-- Portfolio Area -->

<section id="portfolio" class="portfolio-area">
    <div class="container">    
        <h2 class="block_title"><?php the_title(); ?></h2>
        <div class="row port cs-style-3">
            <div class="col-md-4 col-sm-6 col-xs-12 item-space">
                <img src="<?= $custom['about-image'][0] ?>" class="img-responsive center-block"/> 
            </div>
            <div class="col-md-8 col-sm-6 col-xs-12 item-space">
                <blockquote>
                    <p class="lead"><?php the_content(); ?></p>
                </blockquote>
            </div>
        </div>
    </div>
    <div class="container">    
        <h2 class="block_title"><?= $custom['second_title'][0] ?></h2>
        <div class="row port cs-style-3">
            <div class="col-md-7 col-sm-6 col-xs-12 item-space">
                <p class="lead"><?= $custom['second_paragraph'][0] ?></p>
            </div>
            <div class="col-md-5 col-sm-6 col-xs-12 item-space">
                <blockquote>
                    <p class="lead"><?php the_field('get_involved_options'); ?></p>
                </blockquote>
            </div>
        </div>
    </div>
</section><!-- portfolio -->
<?php
endwhile;

endif; ?>



<?php get_footer(); ?>
