

<?php
get_header();
?>

<?php require_once("events-home.php");?>

<?php
if ( have_posts() ) : while ( have_posts() ) : the_post();
?>

<section id="portfolio" class="portfolio-area">
    <div class="container">
        <h2 class="block_title"><?php the_title(); ?></h2>
        <strong class="lead text-center"><?php the_content(); ?><br/><br/></strong>
        <div class="row">
            <div class="col-xs-12 text-center">
                <div class="testimonila-block">
                    <div class="name">
                        <h2 class="text-center">Categories</h2>
                    </div>
                    <p class="lead"><?php the_field('categories');?></p>
                    <br/>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-4 col-md-offset-2">
                    <div class="card">                
                        <div class="card-info">
                            <div class="name">
                                <h2>More Info</h2> 
                            </div>
                            <hr>
                            <div class="content">
                                <p>
                                    <?php the_field('extra_information');?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="card">                
                        <div class="card-info">
                            <div class="name">
                                <h2>Fees</h2> 
                            </div>
                            <hr>
                            <div class="content">
                                <p>
                                    Youth - FREE
                                </p>
                                <p>
                                    Junior - €10
                                </p>
                                <p>
                                    Senior - €25 online or €30 on the day
                                </p>
                                <p>
                                    Licence - covered by Biking.ie
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="card">                
                        <div class="card-info">
                            <div class="name">
                                <h2>Schedule</h2> 
                            </div>
                            <hr>
                            <div class="content">
                                <p>
                                    <?php the_field('schedule');?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!--<blockquote>
                        <div class="card card-5 testimonila-block">
                            <h2>Schedule</h2>
                            <p class="lead"><?php the_field('schedule');?></p>
                        </div>
                    </blockquote>-->

                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-md-offset-2">
                <div class="btn-center"><a href="<?php the_field('map_link');?>" class="big button" download>Download Map</a></div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="btn-center"><a href="http://www.sientries.co.uk/series.php?series_id=242" class="big button">Register Now</a></div>
            </div>
        </div>
    </div>

    <!--<div class="col-xs-12">


    </div>-->


    <div class="container-fluid">
        <div class="row">
            <div class="embed-responsive embed-responsive-21by9">
                <iframe class="embed-responsive-item" src="<?php the_field('directions');?>" frameborder="0" style="border: 0;" allowfullscreen="true"></iframe>
            </div>
        </div>
    </div>
</section><!-- testimonial -->

<?php endwhile; endif;?>

<!-- Testimonial Area -->

<?php
get_footer();
?>