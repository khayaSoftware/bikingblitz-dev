

<?php
get_header();
?>

<?php //require_once("events-home.php");?>

<?php
if ( have_posts() ) : while ( have_posts() ) : the_post();
?>
<section id="portfolio" class="portfolio-area">
    <div class="container">
        <h2 class="block_title"><?php the_title(); ?></h2>
        <strong class="lead text-center"><?php the_content(); ?><br/><br/></strong>
        <div class="row">
            <div class="col-xs-12 text-center">
                <div class="testimonila-block">
                    <h2 class="text-center">Categories</h2>
                    <p class="lead"><?php the_field('categories');?></p>
                    <br/>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="testimonila-block">
                        <p><?php the_field('extra_information');?></p>                        
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="testimonila-block">
                        <blockquote>
                            <h2>Schedule</h2>
                            <p class="lead"><?php the_field('schedule');?></p>
                        </blockquote>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="testimonila-block">
                        <h2>Directions</h2>
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m20!1m8!1m3!1d2120.7164144259864!2d-9.4529033!3d53.4408655!3m2!1i1024!2i768!4f13.1!4m9!3e6!4m3!3m2!1d53.441437699999994!2d-9.450440799999999!4m3!3m2!1d53.4413129!2d-9.4504286!5e1!3m2!1sen!2sie!4v1489141443113" frameborder="0" style="border: 0;" allowfullscreen="true"></iframe>
                        </div>
                    </div>
                    <div class="btn-center"><a href="#" class="big button">Download Map</a></div>
                </div>
            </div>
        </div>
    </div>
</section><!-- testimonial -->

<?php endwhile; endif;?>

<!-- Testimonial Area -->

<?php
get_footer();
?>