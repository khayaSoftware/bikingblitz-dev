<?php get_header()?>

<?php
    /* Template Name: Generic */
?>

<?php
    if ( have_posts() ) :
while ( have_posts() ) : the_post();

?>

<!-- Portfolio Area -->

<section id="portfolio" class="portfolio-area">
    <div class="container">    
        <h2 class="block_title"><?php the_title(); ?></h2>
        <blockquote>
            <?php the_content(); ?>
        </blockquote>
    </div>
</section>

<!-- portfolio -->

<?php
    endwhile;
            endif; 
?>

<?php get_footer(); ?>
