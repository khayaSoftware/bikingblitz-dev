<?php get_header()?>
<?php
    /*
*/
?>

<?php // Show the selected frontpage content.
    if ( have_posts() ) :
while ( have_posts() ) : the_post();

?>
<!-- Portfolio Area -->

<section id="portfolio" class="portfolio-area">
    <div class="container">

        <!--
<h2 class="block_title">Welcome!</h2>
-->
        <div class="row port cs-style-3">
            <div class="col-md-4 col-sm-6 col-xs-12 item-space">
                <div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="<?php echo get_post_meta($post->ID, 'ifrane-url', true); ?>" frameborder="0" allowfullscreen="allowfullscreen"></iframe></div>
            </div>
            <div class="col-md-8 col-sm-6 col-xs-12 item-space">
                <blockquote>
                    <p class="lead"><?php get_template_part( 'template-parts/page/content', 'front-page' ); ?></p>
                </blockquote>
            </div>
        </div>
    </div>
</section><!-- portfolio -->
<?php
endwhile;
else : // I'm not sure it's possible to have no posts when this page is shown, but WTH.
get_template_part( 'template-parts/post/content', 'none' );
endif; ?>
<!-- Content Area -->

<!-- services section -->

<!--<section id="services" class="service-area">
<div class="container">
<h2 class="block_title">Services</h2>
<div class="row">
<div class="col-md-3 col-sm-6">
<div class="services">
<div class="service-wrap">    
<i class="pe-7s-science pe-dj pe-va"></i>
<h3>Creative Idea</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, commodi.</p>
</div>
</div>

</div>
<div class="col-md-3 col-sm-6">
<div class="services">
<div class="service-wrap">
<i class="pe-7s-monitor pe-dj pe-va"></i>
<h3>Responsive Design</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, commodi.</p>
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="services">
<div class="service-wrap">
<i class="pe-7s-edit pe-dj pe-va"></i>
<h3>Clean &amp; Nice</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, commodi.</p>
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="services">
<div class="service-wrap">
<i class="pe-7s-config pe-dj pe-va"></i>
<h3>Support</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, commodi.</p>
</div>
</div>
</div>
</div>
</div>
</section> services -->




<!-- Testimonial Area

<section id="testimonial" class="testimonial-area">
<div class="container">
<h2 class="block_title">Testimonials</h2>
<div class="row">
<div class="col-xs-12">
</div>
<div id="testimonial-container" class="col-xs-12">
<div class="testimonila-block">
<img src="assets/images/testimonial.jpg" alt="clients" class="selfshot">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem sed mollitia illum! Molestiae dignissimos, hic dolorem et eius ut nobis. Corrupti totam amet aperiam aut voluptate nobis dolor at soluta.</p>
<strong>Monir Hossain</strong>
<br>
<small>C.E.O</small>
</div>
<div class="testimonila-block">
<img src="assets/images/testimonial2.jpg" alt="clients" class="selfshot">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem sed mollitia illum! Molestiae dignissimos, hic dolorem et eius ut nobis. Corrupti totam amet aperiam aut voluptate nobis dolor at soluta.</p>
<strong>Nur Ul Hossain</strong>
<br>
<small>Project Manager</small>
</div>
<div class="testimonila-block">
<img src="assets/images/testimonial3.jpg" alt="clients" class="selfshot">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem sed mollitia illum! Molestiae dignissimos, hic dolorem et eius ut nobis. Corrupti totam amet aperiam aut voluptate nobis dolor at soluta.</p>
<strong>Hossain Abrar</strong>
<br>
<small>Developer</small>
</div>
</div>
</div>
</div>
</section><!-- testimonial -->

<!-- Contact Area -->




<?php get_footer(); ?>
