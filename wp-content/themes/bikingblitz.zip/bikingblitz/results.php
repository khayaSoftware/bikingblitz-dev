<?php get_header()?>

<?php
    /* Template Name: Results */
?>

<!-- services section -->
<section id="portfolio" class="portfolio-area">
    <div class="container">
        <div class="row">
            <?php // Show the selected frontpage content.
            $query = new WP_Query( array( 'cat' => 4, 'order'=>'ASC' ) );
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post();


            $custom = get_post_custom();

            ?>
            <div class="col-md-4 col-sm-6">
                <div class="card">                
                    <div class="card-info">
                        <div class="name">
                            <h3><?= the_title(); ?></h3> 
                        </div>
                        <hr>
                        <div class="content">
                            <?= the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            endwhile;
            endif; ?>
        </div>
    </div>
</section> 
<!--services -->

<?php get_footer()?>