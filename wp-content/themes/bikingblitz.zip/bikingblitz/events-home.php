<!-- services section -->
<section id="services" class="service-area">
    <div class="container">
        <div class="row">
            <?php // Show the selected frontpage content.
            $query = new WP_Query( array( 'cat' => 3 ) );
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post();


            $custom = get_post_custom();

            ?>
            <div class="col-md-3 col-sm-6">
                <a href="<?= the_permalink(); ?>" class="button">
                <div class="services">
                    <div class="service-wrap">
                        <b><i class="pe-7s-map-marker pe-dj pe-va"></i></b>
                        <h3><?= the_title(); ?></h3>
                        <p><?= the_content(); ?></p>
                        <button class="button">More</a>
                    </div>
                </div>
                </a>
            </div>
            <?php
            endwhile;
            endif; ?>
        </div>
    </div>
</section> 
<!--services -->