<!-- services section -->
<section id="services" class="service-area">
    <div class="container">
        <div class="row">
            <?php // Show the selected frontpage content.
            $query = new WP_Query( array( 'cat' => 3 ) );
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post();


            $custom = get_post_custom();

            ?>
            <div class="col-md-3 col-sm-6">
                <div class="services">
                    <div class="service-wrap">
                        <br/>
                        <br/>
                        <b><img src="<?= get_home_url(); ?>/wp-content/uploads/2017/12/tree.png" class="center-block img-responsive"/></b>
                        <h3><?= the_title(); ?></h3>
                        <p><?= the_content(); ?></p>
                        <a href="<?= the_permalink(); ?>"><button class="button">More</button></a>
                    </div>
                </div>
            </div>
            <?php
            endwhile;
            endif; ?>
        </div>
    </div>
</section> 
<!--services -->