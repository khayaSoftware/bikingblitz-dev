<!DOCTYPE html>

<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 

<html class="no-js"> <!--<![endif]-->
    <head>
        <title>BikingBlitz!</title>

        <!-- meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

    </head>
    <body id="body">
        <!--[if lt IE 7]>
<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

        <!-- Header area -->
        <header id="header">
            <div class="center text-cent,ber">
                <?php $site_title =  get_bloginfo(); ?>
                <?php 
                $date;
                if(date("Y") == "2017"){
                    $date = date("Y")+1;
                }else{
                    $date = date("Y");
                }
                ?>
                <h1 class="bigheadline"><?= $date;?> <?= $site_title; ?>!</h1>
                <h4 class="subheadline"><?php bloginfo('description'); ?></h4>
            </div>
            <div class="bottom">
                <a data-scroll href="#navigation" class="scrollDown animated pulse" id="scrollToContent"><i class="pe-7s-angle-down-circle pe-va"></i></a>
            </div>
        </header>

        <!-- Navigation area -->
        <section id="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-xs-4">
                        <div class="logo">
                            <br/>
                            <?php echo the_custom_logo(); ?>
                            <br/>
                            <br/>
                        </div>
                    </div>
                    <div class="col-xs-8">
                        <div class="nav">
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <!--<ul id="main-navi" class="nav navbar-nav center-block ">
                                    <li><a href="">HOME</a></li>
                                    <li><a href="">ABOUT</a></li>
                                    <li><a href="">EVENTS</a></li>
                                    <li><a href="">RESULTS</a></li>
                                </ul>-->
                                <?php /* Primary navigation */
                                wp_nav_menu( array(
                                    'menu' => 'Primary',
                                    'depth' => 2,
                                    'container' => false,
                                    'menu_id' => 'main-navi',
                                    'menu_class' => 'nav navbar-nav center-block',
                                    //Process nav menu using our custom nav walker
                                    'walker' => new wp_bootstrap_navwalker())
                                           );

                                ?>
                            </div>
                            <button data-placement="bottom" title="Menu" class="menu navbar-toggle" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <i class="pe-7s-menu"></i>
                            </button>
                            <!--<a href="#" data-placement="bottom" title="Menu" class="menu" data-toggle="dropdown"><i class="pe-7s-menu"></i></a>

<div class="dropdown-menu">
<div class="arrow-up"></div>
<ul>
<li><a data-scroll href="#body">Home <i class="pe-7s-home"></i></a><span class="menu-effect"></span></li>
<li><a data-scroll href="#services">Service <i class="pe-7s-config"></i></a><span class="menu-effect"></span></li>
<li><a data-scroll href="#portfolio">Portfolio <i class="pe-7s-glasses"></i></a><span class="menu-effect"></span></li>
<li><a data-scroll href="#testimonial">Testimonial <i class="pe-7s-comment"></i><span class="menu-effect"></span></a></li>
<li><a data-scroll href="#contact">Contact <i class="pe-7s-help1"></i></a><span class="menu-effect"></span></li>
</ul>
</div>-->
                        </div>
                    </div>

                </div>
            </div>            
        </section>
        <?php wp_head() ?>