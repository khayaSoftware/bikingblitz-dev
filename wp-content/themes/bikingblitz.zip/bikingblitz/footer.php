<section id="contact" class="mapWrap">
    <div id="contact-area">
        <div class="container">
            <h2 class="block_title">Supporters</h2>
            <div class="row">
                <div class="col-xs-12">
                </div>
                <div class="col-sm-8">
                    <div class="moreDetails">
                        <ul class="address">

                        </ul>
                    </div>
                </div>

            </div>
        </div><!-- container -->
    </div><!-- contact-area -->
    <div id="social">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <ul class="scoialinks">
                        <li class="normal-txt">Keep in touch</li>
                        <li class="social-icons">
                            <a class="facebook" href="https://www.facebook.com/bikingblitz" target="_blank"></a></li>
                        <li class="social-icons">
                            <a class="twitter" href="https://twitter.com/Biking_ie" target="_blank"></a>
                        </li>
                        <li class="social-icons"><a href="mailto:info@biking.ie"><i class="pe-7s-mail"></i></a></li>
                        <li class="social-icons"><i class="pe-7s-phone lead"></i><span>0834173899</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!-- social -->
</section><!-- contact -->


<!-- Footer Area -->

<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <p class="copyright">© Copyright <?= date("Y") ?> <a href="http://bikingblitz.ie/" target="_blank">BikingBlitz</a></p>
            </div>
            <div class="col-sm-6">
                <p class="designed">Theme by <a href="https://khayasoftware.github.io/" target="_blank">Khaya Khumalo</a></p>
            </div>
        </div>
    </div>
</footer>


<?php wp_footer() ?>
</body>
</html>