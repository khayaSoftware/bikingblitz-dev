<section id="contact" class="mapWrap">
    <div id="contact-area">
        <div class="container">
            <h2 class="block_title">Contact us</h2>
            <div class="row">
                <div class="col-xs-12">
                </div>
                <div class="col-sm-8">
                    <div class="moreDetails">
                        <h2 class="con-title">
                            The Biking Blitz is promoted by <a href="http://www.biking.ie/index.php">Biking.ie.</a></h2>

                        <ul class="address">
                            <li><i class="pe-7s-mail lead"></i><span><a href="mailto:info@biking.ie">info@biking.ie</a></span></li>
                            <li><i class="pe-7s-phone lead"></i><span>0834173899</span></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div><!-- container -->
    </div><!-- contact-area -->
    <div id="social">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <ul class="scoialinks">
                        <li class="normal-txt">Find us on</li>
                        <li class="social-icons">
                            <a class="facebook" href="https://www.facebook.com/bikingblitz" target="_blank"></a></li>
                        <li class="social-icons">
                            <a class="twitter" href="https://twitter.com/Biking_ie" target="_blank"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!-- social -->
</section><!-- contact -->


<!-- Footer Area -->

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <p class="copyright">© Copyright <?= date("Y") ?> <a href="http://bikingblitz.ie/" target="_blank">BikingBlitz</a></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="designed">Theme by <a href="http://themewagon.com" target="_blank">Themewagon</a> and <a href="https://khayasoftware.github.io/" target="_blank">Khaya Khumalo</a></p>
                    </div>
                </div>
            </div>
        </footer>

        
<?php wp_footer() ?>
    </body>
</html>