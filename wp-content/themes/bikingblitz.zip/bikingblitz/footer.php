

<section id="contact" class="mapWrap">
    <div id="contact-area">
        <div class="container">
            <h2 class="block_title">Supporters</h2>
            <div class="row">
                <div class="col-xs-12">
                    <?php //echo do_shortcode("[wpbgallery id=74]"); ?>
                    <?php echo do_shortcode( '[gs_logo title="yes" posts="15" order="ASC" logo_cat="food" mode="vertical" speed="1000" inf_loop="0" ticker="1" logo_color="gray_to_def"]' ); ?>
                </div>
            </div>

            <div class="row text-center">
                <div class="col-xs-12">
                    <a href="https://www.facebook.com/bikingblitz" class="fa fa-facebook"></a>
                    <a href="https://twitter.com/Biking_ie" class="fa fa-twitter"></a>
                    <a href="mailto:info@biking.ie" class="fa fa-envelope"></a>    
                </div>
                <div class="col-xs-12">
                    <p class="lead"><i class="fa fa-phone"></i> 083 4173 899</p>
                </div>
            </div>
        </div><!-- container -->
    </div><!-- contact-area -->
</section><!-- contact -->


<!-- Footer Area -->

<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <p class="copyright">© Copyright <?= date("Y") ?> <a href="http://bikingblitz.ie/" target="_blank">BikingBlitz</a></p>
            </div>
            <div class="col-sm-6">
                <p class="designed">Theme by <a href="https://khayasoftware.github.io/" target="_blank">Khaya Khumalo</a></p>
            </div>
        </div>
    </div>
</footer>


<?php wp_footer() ?>
</body>
</html>