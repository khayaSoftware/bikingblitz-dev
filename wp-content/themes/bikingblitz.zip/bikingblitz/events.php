<?php get_header()?>

<?php
    /* Template Name: Events */
?>

<?php
    if ( have_posts() ) :
while ( have_posts() ) : the_post();

$custom = get_post_custom();


?>

<!-- Portfolio Area -->

<section id="portfolio" class="portfolio-area">
    <div class="container">    
        <h2 class="block_title"><?php the_title(); ?></h2>
        <?php $content = $custom['second_title'][0] ?>
    </div>
</section>

<?php require_once("events-home.php");?>

<section id="services" class="portfolio-area">
    <div class="container">    
        <h2 class="block_title"><?= $content ?></h2>
    </div>
</section>

<!-- portfolio -->

<?php
    endwhile;
            endif; 
?>

<?php get_footer(); ?>
